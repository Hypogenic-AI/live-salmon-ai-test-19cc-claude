"""Local paired experiment; credentials are read only into process memory."""
from concurrent.futures import ProcessPoolExecutor, as_completed
from datetime import datetime, timezone
from functools import partial
import hashlib
import importlib.metadata
import itertools
import json
import multiprocessing
import os
from pathlib import Path
import random
import re
import subprocess
import sys
import tarfile

REPO = Path(__file__).resolve().parent / 'live-salmon'
sys.path.insert(0, str(REPO))
PROFILES = ['gpt4.1', 'sol_medium', 'astra_medium']
VARIANTS = ['P0', 'P1']
CONDITIONS = ['global', 'conditional', 'null']
WORKFLOWS = ['fixed', 'adaptive']


def worker(job, output, expected_hash):
    from experiments.adaptive_analysis import run
    from experiments.adaptive_analysis.analysis import AnalysisSession
    from experiments.adaptive_analysis.data import make_case, make_summary
    from experiments.adaptive_analysis.evaluate import score_submission
    from src.run_ai_scientists import call_openrouter
    if run.code_fingerprint() != expected_hash:
        return {'status': 'blocked', 'reason': 'source_changed', 'job': job}
    seed, condition, profile, variant, workflow = job
    config = run.profile_config(profile, variant)
    case = make_case(seed, condition, n_samples=config.n_samples, n_discovery=config.n_discovery)
    record = run.run_episode(case=case, seed=seed, condition=condition, workflow=workflow,
        config=config, output=Path(output), code_hash=expected_hash,
        session_factory=AnalysisSession, summary_factory=make_summary,
        scorer=score_submission,
        transport=partial(call_openrouter, **run.transport_options(config)))
    return {'job': job, 'status': record['status'], 'path': record['artifact_path'],
            'failure': record.get('failure'), 'usage': record.get('usage'),
            'api_errors': [{'http_status': e.get('http_status'), 'error_code': e.get('error_code')}
                           for e in record['events'] if e['type'] == 'model_call' and e.get('status') == 'failed']}


def jobs(seeds, shuffle_seed):
    result = list(itertools.product(seeds, CONDITIONS, PROFILES, VARIANTS, WORKFLOWS))
    random.Random(shuffle_seed).shuffle(result)
    return result


def stage(base, name, schedule, fingerprint):
    from experiments.adaptive_analysis import run
    output = base / name
    output.mkdir(exist_ok=True)
    progress = []
    # Separate processes avoid global stdout redirection and BLAS limit collisions.
    with ProcessPoolExecutor(max_workers=3, mp_context=multiprocessing.get_context('spawn')) as pool:
        pending = {pool.submit(worker, j, str(output), fingerprint): j for j in schedule}
        for future in as_completed(pending):
            try:
                result = future.result()
            except Exception as exc:
                result = {'job': pending[future], 'status': 'worker_exception',
                          'exception_type': type(exc).__name__}
            progress.append(result)
            run.atomic_save(base / (name + '-progress.json'), {'planned': len(schedule), 'completed': progress})
            print(f'{name} {len(progress)}/{len(schedule)} {result["job"]}: {result["status"]}', flush=True)
            hard_error = (result['status'] in {'worker_exception', 'blocked'}
                          or any(e.get('http_status') in {401, 402, 403, 404} for e in result.get('api_errors', [])))
            if hard_error:
                for queued in pending:
                    queued.cancel()
                print('Infrastructure error: pending work cancelled; running episodes finish and raw records are retained.', flush=True)
                return False
    return True


def main():
    os.chdir(REPO)
    from experiments.adaptive_analysis import run
    try:
        key = subprocess.run(['/usr/bin/pbpaste'], check=True, capture_output=True, text=True).stdout.strip()
    except Exception:
        print('Clipboard unavailable; no model calls made.', flush=True)
        return 2
    if not re.fullmatch(r'sk-or-[A-Za-z0-9_-]{20,}', key):
        print('Clipboard does not contain a bare OpenRouter key; no model calls made.', flush=True)
        return 2
    os.environ['OPENROUTER_KEY'] = key
    del key
    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    base = REPO / 'experiments/adaptive_analysis/artifacts' / ('model-prompt-' + stamp)
    base.mkdir(parents=True, exist_ok=False)
    print('EXPERIMENT_ROOT=' + str(base), flush=True)
    fingerprint = run.code_fingerprint()
    dev = jobs([9010], 2026092201)
    formal = jobs(list(range(301, 306)), 2026092202)
    files = sorted((REPO / 'experiments/adaptive_analysis').glob('*.py')) + sorted((REPO / 'src').glob('*.py')) + sorted((REPO / 'datasets').glob('*.py')) + [REPO / 'pyproject.toml', REPO / 'uv.lock']
    hashes = {str(p.relative_to(REPO)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    with tarfile.open(base / 'source-snapshot.tar.gz', 'w:gz') as archive:
        for path in files:
            archive.add(path, arcname=str(path.relative_to(REPO)))
        archive.add(Path(__file__), arcname='run_model_prompt_experiment.py')
    run.atomic_save(base / 'freeze.json', {
        'frozen_at_utc': datetime.now(timezone.utc).isoformat(),
        'git_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        'code_hash': fingerprint, 'source_file_sha256': hashes,
        'profiles': {p: run.asdict(run.profile_config(p, 'P0')) for p in PROFILES},
        'prompts': {v: run.system_prompt(v) for v in VARIANTS},
        'seeds': list(range(301, 306)), 'development_seed': 9010,
        'conditions': CONDITIONS, 'workflows': WORKFLOWS, 'prompt_variants': VARIANTS,
        'formal_episode_count': 180, 'formal_maximum_model_calls': 900,
        'development_episode_count': 36, 'development_maximum_model_calls': 180,
        'development_schedule': dev, 'formal_schedule': formal,
        'parallel_workers': 3, 'execution_order': 'Seed-fixed randomized submission order; completion order depends on runtime.',
        'retry_policy': 'No automatic retries, output repair, model fallback, or budget increase. Failed outputs are retained.',
        'development_gate': 'Verify each profile produces at least one valid protocol episode; no correctness-based gate. HTTP auth/credits/not-found errors stop queued work.',
        'scope': 'Exploratory paired comparison of model configurations and the four-rule bundle; five seeds per condition; no significance claims.',
        'python': sys.version,
        'dependencies': {n: importlib.metadata.version(n) for n in ['numpy','pandas','scipy','scikit-learn','httpx','threadpoolctl']},
    })
    try:
        if not stage(base, 'development', dev, fingerprint):
            return 1
        records = [json.loads(p.read_text()) for p in (base / 'development').glob('*.json')]
        valid_profiles = {r['config']['profile'] for r in records if r['status'] == 'success'}
        if set(PROFILES) != valid_profiles or run.code_fingerprint() != fingerprint:
            print('Development protocol gate failed; formal experiment not started.', flush=True)
            return 1
        run.atomic_save(base / 'formal-start.json', {'started_at_utc': datetime.now(timezone.utc).isoformat(),
            'code_hash': fingerprint, 'development_successes': sum(r['status'] == 'success' for r in records),
            'development_records': len(records)})
        print('Protocol check complete; starting 180 formal episodes without changing the frozen configuration.', flush=True)
        ok = stage(base, 'formal', formal, fingerprint)
        print('Experiment finished; all raw responses and costs are retained locally.', flush=True)
        return 0 if ok else 1
    finally:
        os.environ.pop('OPENROUTER_KEY', None)


if __name__ == '__main__':
    raise SystemExit(main())
