# Offline model × prompt reporting

This is the historical reporting schema retained with the frozen experiment. The command below records the original workspace invocation; do not execute it from a restored archive. Consult the evidence package README.md for the current portable restoration and reporting commands.

```sh
work/live-salmon/.venv/bin/python -B work/summarize_model_prompt_experiment.py \
  EXPERIMENT_ROOT OUTPUT_DIR --repo FROZEN_SOURCE --require-complete
```

`OUTPUT_DIR` must be outside both the source repository and the raw experiment root. A relocated archive works without editing historical absolute paths. `--require-complete` requires all 180 formal and 36 development records to be terminal (`success` or `failed`). Without it, absent or running configurations produce an explicitly provisional report. `--skip-reference` skips deterministic data regeneration and saved-coefficient min-CV scoring.

No model calls, credentials, network access, or statistical fitting are used. Default auxiliary scoring reconstructs data with the frozen generator, verifies the recorded fingerprint, and applies saved coefficients. Use the frozen source: code, configuration, and prompt mismatches stop report generation.

## Input contract

- `freeze.json`: `code_hash`, `profiles` mapping each name to its full `Config`, `prompts` mapping P0/P1 to exact system text, `prompt_variants`, `seeds`, `development_seed`, `conditions`, `workflows`, `formal_schedule`, `development_schedule`, and each stage's `*_episode_count`. Schedules use `[seed, condition, profile, prompt_variant, workflow]`.
- `development/**/*.json` and `formal/**/*.json`: raw episode records from `run.py`. Raw records are the authoritative ledger, including failures and `previous_attempts`. Duplicate identities are rejected, rather than silently choosing one.
- Optional `{stage}-progress.json`: `planned` and `completed`, each entry carrying `job`, `status`, `path`, `failure`, `usage`. Every listed entry is checked against raw content; historical paths are checked by basename. The ledger may include additional raw records after an interrupted progress update.
- Optional stage summaries with `{plan, runs}` are reconciled when present. The report states exact numbers checked and does not imply nonexistent summaries were validated.

Expected identity is `(profile, prompt_variant, workflow, condition, seed)`; profiles are `gpt4.1`, `sol_medium`, `astra_medium`; prompts P0/P1; workflows fixed/adaptive; conditions global/conditional/null; formal seeds 301–305; separate development seed 9010. The freeze must declare this exact matrix. Missing raw cells are reported, not treated as zero measured outcomes.

## Outputs

- `REPORT.md`: English outcomes, resource coverage, paired contrasts, action behavior, min-CV reference and separate development/formal spending.
- `中文摘要.md`: Chinese result and comparison summary with the same denominator rules.
- `metrics.json`: frozen provenance; input SHA-256 hashes; validation counts; each stage's full flat rows, 36 grouped cells, missing identities, and cost coverage; paired seed-level deltas; deduplicated auxiliary reference.
- `TRAJECTORIES.md`: every raw episode and retained attempt, in explicit stage/profile/prompt/data/seed/workflow order; actual action payloads, remaining actions, result summaries, provider metadata, submitted explanation, and post-submission scores.
- `EXPLANATION_AUDIT.jsonl`: one evidence packet per retained attempt. Includes the exact submitted explanation, final-call discovery summary, every public candidate card visible in the final history, selected and minimum-CV candidates, family minima, citations, numerical mentions, performed-scan flags, unused budget, and separately labeled hidden outcomes.
- `EXPLANATION_AUDIT.md`: complete review index and explanation packets with selected/minimum/family-level evidence. Detailed public cards remain in JSONL.

## Denominators and contrasts

Groups always contain `n_planned`, `n_present`, `n_missing`, `n_success`, `n_failed`, and `n_nonterminal`. Structure successes are shown over planned episodes; missing records make the report provisional. MSE and false-selection metrics use only successful applicable episodes, and expose their `n`. Cost totals include every retained attempt; unknown billing or reasoning tokens remain unknown and show coverage. Reasoning tokens are not added to total tokens.

`paired_comparisons` always labels the subtraction: `P1_minus_P0` within profile/workflow/condition/seed, or `adaptive_minus_fixed` within profile/prompt/condition/seed. Structure differences require two terminal records and score execution failures as no success; MSE/false-selection differences require two successes. Cost differences require known values and include failed-attempt resources. Each metric retains its own paired denominator, individual seeds, and left/right values.

The auxiliary min-CV reference uses completed fixed evidence only. It requires all 3,612 candidate records, verifies that the best exposed candidate equals the exhaustive best, and checks repeated fixed records across profiles/prompts. It is deduplicated by stage/seed/condition. The reference does not create additional experimental episodes or API costs.

## Explanation review rules

All attempts start `unreviewed`; the script performs no LLM judging. The human/agent reviewer should classify each claim against the packet as supported, unsupported, contradicted, or unverifiable, citing exact evidence IDs/numbers and preserving uncertainty. Review performed-analysis claims, numeric comparisons, uncertainty/complexity language, and stopping rationales separately.

`selected_cv_minus_minimum_exposed` is descriptive. Selecting a simpler candidate can be reasonable; a nonzero gap is not automatically an error. `null_seen` means a fitted null model appeared in the actual final payload. Fixed exhaustive evidence contains both scans without calling `diagnose`, so zero explicit scan calls are not missing evidence. Unused action budget is not automatically wasted budget. Post-submission hidden outcomes must not be used to pretend the model possessed information it did not see.

The report is a local descriptive experiment with five seeds per formal cell. It does not establish causal discovery, calibrated false-positive control, maintainer acceptance, or a general model ranking. Full records and failures are retained; no success-based case selection is used.
